<template>
  <div class="app-container">
    
  </div>
</template>

<script>
export default {
  data() {
    return {
  
    }
  },
  methods: {
    
  }
}
</script>

<style scoped>
.line{
  text-align: center;
}
</style>

